from .needletail import *

__doc__ = needletail.__doc__
if hasattr(needletail, "__all__"):
    __all__ = needletail.__all__